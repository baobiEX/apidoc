<?php

$api = new apidemo('Public Key', 'Private Key', 'bcc');
$api->get_balance();

class apidemo
{

	/**
	 * API URL
	 *
	 * @var string
	 */
	private $apiurl = 'https://api.btctrade.im/api/v1/';

	/**
	 * Public Key
	 * Apply address：https://www.btctrade.im/api/secret/keys/
	 *
	 * @var string
	 */
	private $key;

	/**
	 * Private Key
	 * Apply address：https://www.btctrade.im/api/secret/keys/
	 *
	 * @var string
	 */
	private $passphrase;

	/**
	 * Coin
	 */
	public $coin;

	/**
	 * construct
	 */
	public function __construct($key = false, $passphrase = false, $coin = 'bcc')
	{
		$this->key = $key;
		$this->passphrase = $passphrase;
		$this->coin = $coin;
	}

	/**
	 * Market
	 *
	 * @return array
	 * @access open
	 */
	public function ticker()
	{
		return $this->request('ticker', array(), 'GET', false);
	}

	/**
	 * Depth
	 *
	 * @return array
	 * @access open
	 */
	public function get_depth()
	{
		return $this->request('depth', array(), 'GET', false);
	}


	/**
	 * Account Balance
	 *
	 * @return array
	 * @access readonly
	 */
	public function get_balance()
	{
		return $this->request('balance', array(), 'POST');
	}

	/**
	 * Get your recent orders
	 *
	 * @param integer $since After a time（Default All）
	 * @param string open|all $type type
	 *
	 * @return array
	 * @access readonly
	 */
	public function get_orders($since = 0, $type = 'all')
	{
		return $this->request('trust_list', array('since' => $since, 'type' => $type), 'POST');
	}


	/**
	 * Order Details
	 *
	 * @param integer $orderid Orders Id
	 *
	 * @return array
	 * @access readonly
	 */
	public function fetch_order($orderid)
	{
		return $this->request('trust_view', array('id' => $orderid), 'POST');
	}

	/**
	 * Cancel Order
	 *
	 * @param integer $orderid Order ID
	 *
	 * @return array
	 * @access full
	 */
	public function cancel_order($orderid)
	{
		return $this->request('trust_cancel', array('id' => $orderid), 'POST');
	}

	/**
	 * Trade
	 *
	 * @param float $amount number
	 * @param float $price price
	 *
	 * @return array
	 * @access full
	 */
	public function add($amount, $price, $type)
	{
		return $this->request('trust_add', array('amount' => $amount, 'price' => $price, 'type' => $type), 'POST');
	}

	/**
	 * Request
	 *
	 * @param string $method API Url
	 * @param array $params Parameters
	 * @param string GET|POST $http_method Request method
	 * @param bool $auth is Verify
	 *
	 * @return array
	 */
	protected function request($method, $params = array(), $http_method = 'GET', $auth = true)
	{
		# coin
		$params['coin'] = $this->coin;
		if ($auth) {
			# Unique number
			$mt = explode(' ', microtime());
			$params['nonce'] = $mt[1] . substr($mt[0], 2, 2);
			# verify information
			$params['key'] = $this->key;
			$params['signature'] = hash_hmac('sha256', http_build_query($params, '', '&'), md5($this->passphrase));
		}
		# data string
		$data = http_build_query($params, '', '&');
		$data = $this->do_curl($method, $data, ($http_method == 'GET' ? 'GET' : 'POST'));
		return $data;
	}

	/**
	 * Request
	 */
	private function do_curl($path, $data, $http_method)
	{
		static $ch = null;
		$url = $this->apiurl . $path;
		if (is_null($ch)) {
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; Trade PHP client; ' . php_uname('s') . '; PHP/' . phpversion() . ')');
		}
		if ($http_method == 'GET') {
			$url .= '?' . $data;
		} else {
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
		if (!$response = curl_exec($ch)) {
			throw new Exception('Could not get reply: ' . curl_error($ch));
		}
		if (!$data = json_decode($response, true)) {
			throw new Exception('Invalid data received');
		}
		return $data;
	}
}